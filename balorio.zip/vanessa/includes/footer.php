</main>

<footer class="site-footer">
    <div class="container">
        <p>User Manager &middot; PHP &amp; MySQL</p>
    </div>
</footer>

</body>
</html>
