<?php
require_once __DIR__ . "/helpers.php";
require_once __DIR__ . "/../dao/config.php";

$pageTitle = $pageTitle ?? "Users";
$current   = basename($_SERVER["PHP_SELF"] ?? "");
$flash     = getFlash();
$flashType = in_array(($flash["type"] ?? ""), ["success", "danger", "warning", "info"], true)
    ? $flash["type"]
    : "info";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="read.php">User Manager</a>
        <nav class="site-nav">
            <a href="read.php" class="<?= $current === "read.php" || $current === "edit.php" ? "active" : "" ?>">Users</a>
            <a href="add.php" class="<?= $current === "add.php" ? "active" : "" ?>">Add User</a>
        </nav>
    </div>
</header>

<main class="container">
<?php if ($flash): ?>
    <div class="alert alert-<?= e($flashType) ?>" role="alert">
        <?php if (is_array($flash["message"])): ?>
            <strong>Please fix the following:</strong>
            <ul>
                <?php foreach ($flash["message"] as $msg): ?>
                    <li><?= e($msg) ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <?= e($flash["message"]) ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
