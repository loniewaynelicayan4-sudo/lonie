# User Manager — PHP & MySQL CRUD

A small CRUD application (list / add / edit / delete users) built with PHP, PDO
and MySQL. It runs on Laragon locally and on InfinityFree in production.

## Files

```
index.php              → redirects to pages/read.php
test_connection.php    → database connection diagnostic
dao/config.php         → ALL database settings (the only file to edit)
dao/crudDAO.php        → data access class (prepared statements, password hashing)
includes/              → shared layout + helpers
pages/                 → read / add / edit screens
process/               → create / update / delete handlers
database/oop_crud.sql  → table structure + sample data
```

## Deploy to InfinityFree (step by step)

1. **Create the database.** In vPanel open **MySQL Databases** and create a
   database with the suffix `db_iwayan`. vPanel will show the full name as
   `if0_43452544_db_iwayan`.
2. **Check the four values.** `dao/config.php` is already set to:

   | Setting  | Value                          |
   |----------|--------------------------------|
   | Host     | `sql202.infinityfree.com`      |
   | Port     | `3306`                         |
   | Database | `if0_43452544_db_iwayan`       |
   | Username | `if0_43452544`                 |
   | Password | `aP3vpzNeS1hUayt`              |

   If vPanel shows a different host or database name, edit **only** the
   `$production` block at the top of `dao/config.php`.
3. **Upload the files.** Use the InfinityFree file manager or FTP and upload
   everything to `htdocs`. Upload the hidden `.htaccess` file too, and keep the
   folder structure (`assets/`, `dao/`, `includes/`, `pages/`, `process/`,
   `database/`).
4. **Import the SQL.** Open **phpMyAdmin** for your database, select
   `if0_43452544_db_iwayan` in the left sidebar, go to **Import**, and upload
   `database/oop_crud.sql`.
5. **Set the PHP version.** In vPanel make sure PHP **8.2** or **8.3** is
   selected for the domain.
6. **Open your domain.** It should redirect to the user list automatically.
7. **Verify the connection** at
   `https://your-domain/test_connection.php?key=vanessa-db-check`.
   Keep the `?key=` part — full details are hidden on the live site without it.

## Local development (Laragon / XAMPP)

1. Create a database named `oop_crud` and import `database/oop_crud.sql`.
2. Open the project through your local virtual host (e.g.
   `http://vanessa.test`) or `http://localhost/vanessa`.
3. Local settings are the `$local` block in `dao/config.php`
   (`root` / empty password by default).

The app detects the environment automatically: localhost, `127.0.0.1`,
`*.test` and `*.local` use the local settings; any real domain uses the
production settings.

## Sample users

The SQL file inserts 10 users. Their stored password is:

```
Password123!
```

There is no login page, so this password is only relevant if you build one.

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Database connection failed" | Re-check host, database name, username and password in `dao/config.php`. On InfinityFree the host is `sqlXXX.infinityfree.com`, never `localhost`. |
| "Access denied for user" | The database user must be attached to the database in vPanel. Delete the database and recreate it, or create the user/database pair again. |
| "Unknown database" | The name in `dao/config.php` must exactly match the full name shown in vPanel. |
| "Table 'users' doesn't exist" | Import `database/oop_crud.sql` while the correct database is selected in phpMyAdmin. |
| HTTP 500 on every page | Check the PHP version in vPanel (use 8.2/8.3) and the hosting error log. Try temporarily renaming `.htaccess`. |
| Page has no styling | The `assets/` folder was not uploaded, or it was uploaded with a different name/case. |
