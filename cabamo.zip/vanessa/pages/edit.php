<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

$pageTitle = "Edit User";
$crud = new crudDAO();
$id   = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
$user = false;

if ($id) {
    try {
        $user = $crud->readOne($id);
    } catch (PDOException $e) {
        $user = false;
    }
}

if (!$user) {
    flash("warning", "User not found.");
    redirect("read.php");
}

$old = getOld();
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Edit User</h1>
        <p class="subtitle">Update the details for <strong><?= e($user["fname"] . " " . $user["lname"]) ?></strong>.</p>
    </div>
</div>

<div class="panel form-panel">
    <form method="POST" action="../process/update.php" novalidate>
        <?= csrfField() ?>
        <input type="hidden" name="id" value="<?= e($user["id"]) ?>">

        <div class="field-row">
            <div class="field">
                <label for="fname" class="required">First Name</label>
                <input type="text" id="fname" name="fname" maxlength="50"
                       value="<?= e($old["fname"] ?? $user["fname"]) ?>" autocomplete="given-name" required>
            </div>

            <div class="field">
                <label for="lname" class="required">Last Name</label>
                <input type="text" id="lname" name="lname" maxlength="50"
                       value="<?= e($old["lname"] ?? $user["lname"]) ?>" autocomplete="family-name" required>
            </div>
        </div>

        <div class="field">
            <label for="username" class="required">Username</label>
            <input type="text" id="username" name="username" maxlength="50"
                   value="<?= e($old["username"] ?? $user["username"]) ?>" autocomplete="username" required>
            <small>3-50 characters using letters, numbers, dots, underscores, or hyphens.</small>
        </div>

        <div class="field">
            <label for="email" class="required">Email Address</label>
            <input type="email" id="email" name="email" maxlength="50"
                   value="<?= e($old["email"] ?? $user["email"]) ?>" autocomplete="email" required>
        </div>

        <div class="field">
            <label for="password">New Password</label>
            <input type="password" id="password" name="password" maxlength="72"
                   pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,72}"
                   title="Use 8-72 characters with uppercase, lowercase, a number, and a symbol."
                   autocomplete="new-password">
            <small>Leave this blank to keep the current password. Otherwise use 8-72 characters with uppercase, lowercase, a number, and a symbol.</small>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save Changes</button>
            <a class="btn btn-secondary" href="read.php">Cancel</a>
        </div>
    </form>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
