<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

$pageTitle = "Users";

$list = [];
try {
    $list = (new crudDAO())->read();
} catch (PDOException $e) {
    flash("danger", "Could not load users. Did you import the database schema?");
}
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Users</h1>
        <p class="subtitle">View, add, edit, and delete user records.</p>
    </div>
    <a class="btn btn-primary" href="add.php">+ Add New User</a>
</div>

<div class="panel">
    <div class="panel-head">
        <h2>All Users</h2>
        <span class="count"><?= count($list) ?> user<?= count($list) === 1 ? "" : "s" ?> total</span>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Last Name</th>
                    <th>First Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th class="actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($list): ?>
                <?php foreach ($list as $value): ?>
                    <tr>
                        <td><?= e($value['id']) ?></td>
                        <td><?= e($value['lname']) ?></td>
                        <td><?= e($value['fname']) ?></td>
                        <td><?= e($value['username']) ?></td>
                        <td><?= e($value['email']) ?></td>
                        <td class="actions">
                            <a class="btn btn-sm btn-outline" href="edit.php?id=<?= e($value['id']) ?>">Edit</a>
                            <form method="POST" action="../process/delete.php" class="inline-form"
                                  onsubmit="return confirm('Do you really want to delete this user?');">
                                <?= csrfField() ?>
                                <input type="hidden" name="id" value="<?= e($value['id']) ?>">
                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="empty">
                        <strong>No users yet.</strong>
                        <a href="add.php">Add the first user</a>.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
