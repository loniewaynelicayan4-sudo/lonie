<?php
require_once __DIR__ . "/../includes/helpers.php";
$old       = getOld();
$pageTitle = "Add User";
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Add New User</h1>
        <p class="subtitle">Fill in the details below and click Save User.</p>
    </div>
</div>

<div class="panel form-panel">
    <form method="POST" action="../process/create.php" novalidate>
        <?= csrfField() ?>

        <div class="field-row">
            <div class="field">
                <label for="fname" class="required">First Name</label>
                <input type="text" id="fname" name="fname" maxlength="50"
                       value="<?= e($old["fname"] ?? "") ?>" autocomplete="given-name" required>
            </div>

            <div class="field">
                <label for="lname" class="required">Last Name</label>
                <input type="text" id="lname" name="lname" maxlength="50"
                       value="<?= e($old["lname"] ?? "") ?>" autocomplete="family-name" required>
            </div>
        </div>

        <div class="field">
            <label for="username" class="required">Username</label>
            <input type="text" id="username" name="username" maxlength="50"
                   value="<?= e($old["username"] ?? "") ?>" autocomplete="username" required>
            <small>3-50 characters using letters, numbers, dots, underscores, or hyphens.</small>
        </div>

        <div class="field">
            <label for="email" class="required">Email Address</label>
            <input type="email" id="email" name="email" maxlength="50"
                   value="<?= e($old["email"] ?? "") ?>" autocomplete="email" required>
        </div>

        <div class="field">
            <label for="password" class="required">Password</label>
            <input type="password" id="password" name="password"
                   minlength="8" maxlength="72"
                   pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,72}"
                   title="Use 8-72 characters with uppercase, lowercase, a number, and a symbol."
                   autocomplete="new-password" required>
            <small>8-72 characters with uppercase, lowercase, a number, and a symbol.</small>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save User</button>
            <a class="btn btn-secondary" href="read.php">Cancel</a>
        </div>
    </form>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
