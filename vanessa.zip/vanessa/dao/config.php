<?php
// ---------------------------------------------------------------------------
// Database configuration
// ---------------------------------------------------------------------------
// This is the ONLY file you need to edit to deploy the app. It contains both
// the local (Laragon / XAMPP) and the InfinityFree settings, and the app picks
// the right one automatically based on the domain it is running on.
//
// Localhost / 127.0.0.1 / *.test / *.local  -> local settings
// Any real domain (e.g. your InfinityFree domain) -> production settings
//
// You can also force an environment by defining DB_ENV ("local" or
// "production") before including this file.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 1. InfinityFree credentials
// ---------------------------------------------------------------------------
// Copy these four values from vPanel -> MySQL Databases. The database host is
// NOT "localhost" on InfinityFree; it looks like "sql123.infinityfree.com".
// The database name is the full name shown there, e.g. "if0_12345678_oop_crud".
// ---------------------------------------------------------------------------
$production = [
    "host" => getenv("DB_HOST") ?: "sql202.infinityfree.com",
    "port" => (int) (getenv("DB_PORT") ?: 3306),
    "name" => getenv("DB_NAME") ?: "if0_43452544_oop_crud",
    "user" => getenv("DB_USER") ?: "if0_43452544",
    "pass" => getenv("DB_PASS") ?: "aP3vpzNeS1hUayt",
];

// ---------------------------------------------------------------------------
// 2. Local development credentials (Laragon / XAMPP defaults)
// ---------------------------------------------------------------------------
$local = [
    "host" => getenv("DB_LOCAL_HOST") ?: "localhost",
    "port" => (int) (getenv("DB_LOCAL_PORT") ?: 3306),
    "name" => getenv("DB_LOCAL_NAME") ?: "oop_crud",
    "user" => getenv("DB_LOCAL_USER") ?: "root",
    "pass" => getenv("DB_LOCAL_PASS") ?: "",
];

// Optional key that unlocks full connection details on test_connection.php.
// Example: test_connection.php?key=vanessa-db-check
if (!defined("DB_DEBUG_KEY")) {
    define("DB_DEBUG_KEY", "vanessa-db-check");
}

// ---------------------------------------------------------------------------
// 3. Environment detection (nothing to edit below this line)
// ---------------------------------------------------------------------------
$httpHost = isset($_SERVER["HTTP_HOST"]) ? strtolower((string) $_SERVER["HTTP_HOST"]) : "";
$httpHost = preg_replace('/:\d+$/', "", $httpHost); // strip ":8080"

$isLocal = PHP_SAPI === "cli"
    || $httpHost === ""
    || $httpHost === "localhost"
    || $httpHost === "127.0.0.1"
    || $httpHost === "::1"
    || $httpHost === "[::1]"
    || substr($httpHost, -5) === ".test"
    || substr($httpHost, -6) === ".local"
    || substr($httpHost, -10) === ".localhost";

$env = defined("DB_ENV") ? strtolower((string) DB_ENV) : ($isLocal ? "local" : "production");
$cfg = ($env === "production") ? $production : $local;

$host       = $cfg["host"];
$dbPort     = isset($cfg["port"]) ? (int) $cfg["port"] : 3306;
$dbname     = $cfg["name"];
$dbUser     = $cfg["user"];
$dbPassword = $cfg["pass"];
$currentEnv = $env;

/**
 * Create a PDO connection using the credentials above.
 * Throws PDOException on failure so callers can decide how to react.
 */
function dbConnect(): PDO
{
    global $host, $dbPort, $dbname, $dbUser, $dbPassword;

    return new PDO(
        "mysql:host={$host};port={$dbPort};dbname={$dbname};charset=utf8mb4",
        $dbUser,
        $dbPassword,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 10,
        ]
    );
}

/**
 * Friendly, credential-safe error page shown when the database is unreachable.
 */
function dbConnectionFailed(PDOException $e): void
{
    global $isLocal;

    if (PHP_SAPI === "cli") {
        fwrite(STDERR, "Database connection failed: " . $e->getMessage() . PHP_EOL);
        exit(1);
    }

    error_log("Database connection failed: " . $e->getMessage());
    http_response_code(500);
    header("Content-Type: text/html; charset=UTF-8");

    $details = "";
    if ($isLocal) {
        $details = '<p style="color:#b02a37;font-size:.9rem;word-break:break-word">'
            . htmlspecialchars($e->getMessage(), ENT_QUOTES, "UTF-8")
            . "</p>";
    }

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>Database connection failed</title><style>'
        . 'body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:#f5f6f8;'
        . 'color:#1f2937;margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;padding:1.5rem}'
        . '.card{background:#fff;border:1px solid #e3e6ea;border-radius:12px;box-shadow:0 4px 24px rgba(15,23,42,.06);'
        . 'max-width:520px;padding:2rem}h1{font-size:1.25rem;margin:0 0 .75rem}'
        . 'p{line-height:1.55;margin:.5rem 0;color:#4b5563}.hint{background:#f8f9fa;border-left:3px solid #0d6efd;'
        . 'padding:.75rem 1rem;border-radius:6px;font-size:.9rem}'
        . '</style></head><body><div class="card">'
        . '<h1>Database connection failed</h1>'
        . '<p>The application could not connect to the database.</p>'
        . '<p class="hint">If you just deployed, open <strong>dao/config.php</strong> and check the '
        . 'MySQL host, database name, username and password against your hosting control panel.</p>'
        . $details
        . "</div></body></html>";
    exit;
}

// The rest of the app expects a ready-to-use $db. Diagnostic scripts can
// define DB_SKIP_AUTOCONNECT before including this file to handle errors themselves.
if (!defined("DB_SKIP_AUTOCONNECT")) {
    try {
        $db = dbConnect();
    } catch (PDOException $e) {
        dbConnectionFailed($e);
    }
}
