-- ---------------------------------------------------------------------------
-- Import this file into an EXISTING database.
--   * Laragon: create/select a database named "oop_crud", then import.
--   * InfinityFree: in vPanel create a database with the suffix "oop_crud"
--     (its full name becomes "if0_43452544_oop_crud"), select it in phpMyAdmin,
--     then import this file.
-- The two lines below are only needed if your import tool has no database
-- selected, so they are commented out to keep the file portable.
-- ---------------------------------------------------------------------------
-- CREATE DATABASE IF NOT EXISTS oop_crud
--     CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE oop_crud;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(50) NOT NULL,
    status TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_username (username),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- All sample users have the password: Password123!
-- (stored as a bcrypt hash, generated with PHP's password_hash())
INSERT INTO users (username, fname, lname, password, email, status) VALUES
('jdoe', 'John', 'Doe', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'john.doe@example.com', 1),
('asmith', 'Anna', 'Smith', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'anna.smith@example.com', 1),
('mjohnson', 'Michael', 'Johnson', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'michael.johnson@example.com', 1),
('mbrown', 'Maria', 'Brown', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'maria.brown@example.com', 1),
('dwilson', 'David', 'Wilson', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'david.wilson@example.com', 1),
('jgarcia', 'Julia', 'Garcia', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'julia.garcia@example.com', 1),
('rmartin', 'Robert', 'Martin', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'robert.martin@example.com', 1),
('llee', 'Linda', 'Lee', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'linda.lee@example.com', 1),
('kclark', 'Kevin', 'Clark', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'kevin.clark@example.com', 1),
('tanderson', 'Taylor', 'Anderson', '$2y$10$BqaOp6YGQeLfUv8cNtyOkO14bUJCxG/QJXRgE5HWNURupbvqTqXCW', 'taylor.anderson@example.com', 1);
