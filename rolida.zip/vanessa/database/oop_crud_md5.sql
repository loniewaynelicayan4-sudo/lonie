-- ---------------------------------------------------------------------------
-- COMPLETE DATABASE SETUP
-- Creates the "users" table and inserts 20 users with MD5-hashed passwords.
--
-- HOW TO IMPORT (InfinityFree / phpMyAdmin):
--   1. In vPanel, open phpMyAdmin for your database.
--   2. Click your database name in the left sidebar (e.g. if0_43452544_oop_crud).
--   3. Go to the "Import" tab.
--   4. Choose this file (oop_crud_md5.sql) and click "Go".
--
-- All 20 users share the password: password123
-- MD5: 482c811da5d5b4bc6d497ffa98491e38
--
-- WARNING: the DROP TABLE line below erases an existing "users" table.
-- Remove that line if you want to keep existing data.
-- ---------------------------------------------------------------------------

DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(50) NOT NULL,
    status TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_username (username),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users (username, fname, lname, password, email, status) VALUES
('awilliams',  'Alice',   'Williams',  '482c811da5d5b4bc6d497ffa98491e38', 'alice.williams@example.com',   1),
('bjones',     'Brian',   'Jones',     '482c811da5d5b4bc6d497ffa98491e38', 'brian.jones@example.com',      1),
('cgarcia',    'Carla',   'Garcia',    '482c811da5d5b4bc6d497ffa98491e38', 'carla.garcia@example.com',     1),
('dmiller',    'Daniel',  'Miller',    '482c811da5d5b4bc6d497ffa98491e38', 'daniel.miller@example.com',    1),
('edavis',     'Emma',    'Davis',     '482c811da5d5b4bc6d497ffa98491e38', 'emma.davis@example.com',       1),
('frodriguez', 'Frank',   'Rodriguez', '482c811da5d5b4bc6d497ffa98491e38', 'frank.rodriguez@example.com',  1),
('gmartinez',  'Grace',   'Martinez',  '482c811da5d5b4bc6d497ffa98491e38', 'grace.martinez@example.com',   1),
('hhernandez', 'Henry',   'Hernandez', '482c811da5d5b4bc6d497ffa98491e38', 'henry.hernandez@example.com',  1),
('ilopez',     'Irene',   'Lopez',     '482c811da5d5b4bc6d497ffa98491e38', 'irene.lopez@example.com',      1),
('jgonzalez',  'Jason',   'Gonzalez',  '482c811da5d5b4bc6d497ffa98491e38', 'jason.gonzalez@example.com',   1),
('kwilson',    'Karen',   'Wilson',    '482c811da5d5b4bc6d497ffa98491e38', 'karen.wilson@example.com',     1),
('landerson',  'Louis',   'Anderson',  '482c811da5d5b4bc6d497ffa98491e38', 'louis.anderson@example.com',   1),
('mthomas',    'Maria',   'Thomas',    '482c811da5d5b4bc6d497ffa98491e38', 'maria.thomas@example.com',     1),
('ntaylor',    'Nancy',   'Taylor',    '482c811da5d5b4bc6d497ffa98491e38', 'nancy.taylor@example.com',     1),
('omoore',     'Oscar',   'Moore',     '482c811da5d5b4bc6d497ffa98491e38', 'oscar.moore@example.com',      1),
('pjackson',   'Paula',   'Jackson',   '482c811da5d5b4bc6d497ffa98491e38', 'paula.jackson@example.com',    1),
('qmartin',    'Quentin', 'Martin',    '482c811da5d5b4bc6d497ffa98491e38', 'quentin.martin@example.com',   1),
('rlee',       'Rachel',  'Lee',       '482c811da5d5b4bc6d497ffa98491e38', 'rachel.lee@example.com',       1),
('sperez',     'Samuel',  'Perez',     '482c811da5d5b4bc6d497ffa98491e38', 'samuel.perez@example.com',     1),
('tthompson',  'Tina',    'Thompson',  '482c811da5d5b4bc6d497ffa98491e38', 'tina.thompson@example.com',    1);

-- Verify: should return 20
-- SELECT COUNT(*) FROM users;
