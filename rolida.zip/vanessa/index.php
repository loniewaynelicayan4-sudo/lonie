<?php
header("Location: pages/read.php");
exit;
?>