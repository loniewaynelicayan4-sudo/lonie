<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

requirePost("../pages/add.php");

try {
    $crud   = new crudDAO();
    $errors = validateUser($_POST, $crud, true);

    if ($errors) {
        setOld($_POST);
        flash("danger", $errors);
        redirect("../pages/add.php");
    }

    $crud->create(
        trim($_POST["username"]),
        trim($_POST["fname"]),
        trim($_POST["lname"]),
        $_POST["password"],
        trim($_POST["email"])
    );

    flash("success", "User added successfully.");
    redirect("../pages/read.php");
} catch (PDOException $e) {
    setOld($_POST);
    error_log("Create user failed: " . $e->getMessage());

    $msg = (($e->errorInfo[1] ?? 0) === 1062)
        ? "That username or email is already in use."
        : "Could not add user. Please try again.";

    flash("danger", $msg);
    redirect("../pages/add.php");
}
