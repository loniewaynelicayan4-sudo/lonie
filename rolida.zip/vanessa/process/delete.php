<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

requirePost("../pages/read.php");

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
if (!$id) {
    flash("danger", "Invalid user ID.");
    redirect("../pages/read.php");
}

try {
    $deleted = (new crudDAO())->delete($id);

    if ($deleted) {
        flash("success", "User deleted successfully.");
    } else {
        flash("warning", "User not found (it may have already been deleted).");
    }
} catch (PDOException $e) {
    error_log("Delete user failed: " . $e->getMessage());
    flash("danger", "Could not delete user. Please try again.");
}

redirect("../pages/read.php");
