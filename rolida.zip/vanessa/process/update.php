<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

requirePost("../pages/read.php");

$id = filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT);
if (!$id) {
    flash("danger", "Invalid user ID.");
    redirect("../pages/read.php");
}

$back = "../pages/edit.php?id=" . $id;

try {
    $crud = new crudDAO();

    if (!$crud->readOne($id)) {
        flash("warning", "User not found.");
        redirect("../pages/read.php");
    }

    $errors = validateUser($_POST, $crud, false, $id);
    if ($errors) {
        setOld($_POST);
        flash("danger", $errors);
        redirect($back);
    }

    $crud->update(
        $id,
        trim($_POST["username"]),
        trim($_POST["fname"]),
        trim($_POST["lname"]),
        trim($_POST["email"]),
        $_POST["password"] ?? ""
    );

    flash("success", "User updated successfully.");
    redirect("../pages/read.php");
} catch (PDOException $e) {
    setOld($_POST);
    error_log("Update user failed: " . $e->getMessage());

    $msg = (($e->errorInfo[1] ?? 0) === 1062)
        ? "That username or email is already in use."
        : "Could not update user. Please try again.";

    flash("danger", $msg);
    redirect($back);
}
