<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

$pageTitle = "Edit User";
$crud = new crudDAO();
$id   = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);
$user = false;

if ($id) {
    try {
        $user = $crud->readOne($id);
    } catch (PDOException $e) {
        $user = false;
    }
}

if (!$user) {
    flash("warning", "User not found.");
    redirect("read.php");
}

$old = getOld();
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Edit user #<?= e($user["id"]) ?></h1>
        <p class="muted"><a href="read.php">Back to users</a></p>
    </div>
</div>

<div class="card card-narrow">
    <form method="POST" action="../process/update.php" novalidate>
        <?= csrfField() ?>
        <input type="hidden" name="id" value="<?= e($user["id"]) ?>">

        <div class="field">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" maxlength="50"
                   value="<?= e($old["username"] ?? $user["username"]) ?>" autocomplete="username" required>
        </div>

        <div class="field">
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="fname" maxlength="50"
                   value="<?= e($old["fname"] ?? $user["fname"]) ?>" autocomplete="given-name" required>
        </div>

        <div class="field">
            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="lname" maxlength="50"
                   value="<?= e($old["lname"] ?? $user["lname"]) ?>" autocomplete="family-name" required>
        </div>

        <div class="field">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" maxlength="50"
                   value="<?= e($old["email"] ?? $user["email"]) ?>" autocomplete="email" required>
        </div>

        <div class="field">
            <label for="password">New Password</label>
            <input type="password" id="password" name="password" maxlength="72"
                   pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,72}"
                   title="Use 8-72 characters with uppercase, lowercase, a number, and a symbol."
                   autocomplete="new-password">
            <small>Leave blank to keep the current password. Otherwise use 8-72 characters with uppercase, lowercase, a number, and a symbol.</small>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">Update user</button>
            <a class="btn btn-secondary" href="read.php">Cancel</a>
        </div>
    </form>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
