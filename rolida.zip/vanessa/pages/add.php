<?php
require_once __DIR__ . "/../includes/helpers.php";
$old       = getOld();
$pageTitle = "Add User";
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Add user</h1>
        <p class="muted"><a href="read.php">Back to users</a></p>
    </div>
</div>

<div class="card card-narrow">
    <form method="POST" action="../process/create.php" novalidate>
        <?= csrfField() ?>

        <div class="field">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" maxlength="50"
                   value="<?= e($old["username"] ?? "") ?>" autocomplete="username" required>
        </div>

        <div class="field">
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="fname" maxlength="50"
                   value="<?= e($old["fname"] ?? "") ?>" autocomplete="given-name" required>
        </div>

        <div class="field">
            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="lname" maxlength="50"
                   value="<?= e($old["lname"] ?? "") ?>" autocomplete="family-name" required>
        </div>

        <div class="field">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" maxlength="50"
                   value="<?= e($old["email"] ?? "") ?>" autocomplete="email" required>
        </div>

        <div class="field">
            <label for="password">Password</label>
            <input type="password" id="password" name="password"
                   minlength="8" maxlength="72"
                   pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,72}"
                   title="Use 8-72 characters with uppercase, lowercase, a number, and a symbol."
                   autocomplete="new-password" required>
            <small>8-72 characters with uppercase, lowercase, a number, and a symbol.</small>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save User</button>
            <a class="btn btn-secondary" href="read.php">Cancel</a>
        </div>
    </form>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
