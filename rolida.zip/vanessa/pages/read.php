<?php
require_once __DIR__ . "/../dao/config.php";
require_once __DIR__ . "/../dao/crudDAO.php";
require_once __DIR__ . "/../includes/helpers.php";

$pageTitle = "Users";

$list = [];
try {
    $list = (new crudDAO())->read();
} catch (PDOException $e) {
    flash("danger", "Could not load users. Did you import the database schema?");
}
require __DIR__ . "/../includes/header.php";
?>

<div class="page-head">
    <div>
        <h1>Users</h1>
        <p class="muted"><?= count($list) ?> account<?= count($list) === 1 ? "" : "s" ?></p>
    </div>
    <a class="btn btn-primary" href="add.php">Add user</a>
</div>

<div class="card">
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Lastname</th>
                    <th>Firstname</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th class="actions-col">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($list): ?>
                <?php foreach ($list as $value): ?>
                    <tr>
                        <td><?= e($value['id']) ?></td>
                        <td><?= e($value['lname']) ?></td>
                        <td><?= e($value['fname']) ?></td>
                        <td><?= e($value['username']) ?></td>
                        <td><?= e($value['email']) ?></td>
                        <td class="actions">
                            <a class="btn btn-small btn-secondary" href="edit.php?id=<?= e($value['id']) ?>">Edit</a>
                            <form method="POST" action="../process/delete.php" class="inline-form"
                                  onsubmit="return confirm('Do you really want to delete this user?');">
                                <?= csrfField() ?>
                                <input type="hidden" name="id" value="<?= e($value['id']) ?>">
                                <button class="btn btn-small btn-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" class="empty">No users found. <a href="add.php">Add the first one</a>.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . "/../includes/footer.php"; ?>
