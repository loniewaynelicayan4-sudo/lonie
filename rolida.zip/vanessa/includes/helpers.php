<?php
// ---------------------------------------------------------------------------
// Shared helpers: sessions, escaping, CSRF protection and validation.
// ---------------------------------------------------------------------------

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER["HTTPS"]) && strtolower((string) $_SERVER["HTTPS"]) !== "off")
        || (isset($_SERVER["HTTP_X_FORWARDED_PROTO"]) && strtolower((string) $_SERVER["HTTP_X_FORWARDED_PROTO"]) === "https");

    session_set_cookie_params([
        "lifetime" => 0,
        "path"     => "/",
        "secure"   => $isHttps,
        "httponly" => true,
        "samesite" => "Lax",
    ]);

    session_start();
}

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

function textLength(string $s): int
{
    return function_exists("mb_strlen") ? mb_strlen($s, "UTF-8") : strlen($s);
}

function passwordMatchesPolicy(string $password): bool
{
    return (bool) preg_match('/\A(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9])[\x21-\x7E]{8,72}\z/', $password);
}

function redirect(string $url): void
{
    header("Location: " . $url);
    exit;
}

function flash(string $type, $message): void
{
    $_SESSION["flash"] = ["type" => $type, "message" => $message];
}

function getFlash(): ?array
{
    $f = $_SESSION["flash"] ?? null;
    unset($_SESSION["flash"]);

    return is_array($f) ? $f : null;
}

function setOld(array $data): void
{
    unset($data["password"], $data["csrf"]);
    $_SESSION["old"] = $data;
}

function getOld(): array
{
    $old = $_SESSION["old"] ?? [];
    unset($_SESSION["old"]);

    return is_array($old) ? $old : [];
}

function csrfToken(): string
{
    if (empty($_SESSION["csrf"]) || !is_string($_SESSION["csrf"])) {
        $_SESSION["csrf"] = bin2hex(random_bytes(32));
    }

    return $_SESSION["csrf"];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrfToken()) . '">';
}

function csrfValid(): bool
{
    $stored = $_SESSION["csrf"] ?? "";
    $sent   = $_POST["csrf"] ?? "";

    return is_string($sent)
        && $stored !== ""
        && $sent !== ""
        && hash_equals($stored, $sent);
}

function requirePost(string $backUrl): void
{
    if (($_SERVER["REQUEST_METHOD"] ?? "") !== "POST") {
        redirect($backUrl);
    }

    if (!csrfValid()) {
        flash("danger", "Your session expired. Please try again.");
        redirect($backUrl);
    }
}

/**
 * Validate user input. Returns a list of human-readable error messages.
 */
function validateUser(array $in, crudDAO $crud, bool $passwordRequired, int $excludeId = 0): array
{
    $errors = [];

    foreach (["username", "fname", "lname", "email", "password"] as $f) {
        if (isset($in[$f]) && !is_string($in[$f])) {
            return ["Invalid form data."];
        }
    }

    $username = trim($in["username"] ?? "");
    $fname    = trim($in["fname"] ?? "");
    $lname    = trim($in["lname"] ?? "");
    $email    = trim($in["email"] ?? "");
    $password = $in["password"] ?? "";

    if ($username === "") {
        $errors[] = "Username is required.";
    } elseif (!preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username)) {
        $errors[] = "Username must be 3-50 characters (letters, numbers, . _ -).";
    } elseif ($crud->usernameExists($username, $excludeId)) {
        $errors[] = "That username is already taken.";
    }

    if ($fname === "" || textLength($fname) > 50) {
        $errors[] = "First name is required (max 50 characters).";
    }
    if ($lname === "" || textLength($lname) > 50) {
        $errors[] = "Last name is required (max 50 characters).";
    }

    if ($email === "") {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || textLength($email) > 50) {
        $errors[] = "Please enter a valid email address (max 50 characters).";
    } elseif ($crud->emailExists($email, $excludeId)) {
        $errors[] = "That email is already registered.";
    }

    if ($passwordRequired || $password !== "") {
        if (!passwordMatchesPolicy($password)) {
            $errors[] = "Password must be 8-72 characters and include uppercase, lowercase, a number, and a symbol.";
        }
    }

    return $errors;
}
