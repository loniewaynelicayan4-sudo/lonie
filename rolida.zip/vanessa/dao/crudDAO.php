<?php
// ---------------------------------------------------------------------------
// Data access layer for the "users" table.
// All queries use prepared statements, and passwords are hashed with
// password_hash() before they are stored.
// ---------------------------------------------------------------------------
require_once __DIR__ . "/config.php";

class crudDAO
{
    private PDO $db;

    /**
     * @param PDO|null $db Optional connection (useful for tests). When omitted,
     *                     the connection created by config.php is reused.
     */
    public function __construct(?PDO $db = null)
    {
        if ($db instanceof PDO) {
            $this->db = $db;
            return;
        }

        global $db;
        $this->db = ($db instanceof PDO) ? $db : dbConnect();
    }

    /**
     * Return every user. Password hashes are intentionally never selected.
     */
    public function read(): array
    {
        $sql = "SELECT id, username, fname, lname, email, status
                FROM users
                ORDER BY id ASC";

        return $this->db->query($sql)->fetchAll();
    }

    /**
     * Return one user, or null when the id does not exist.
     */
    public function readOne(int $id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT id, username, fname, lname, email, status
             FROM users
             WHERE id = :id
             LIMIT 1"
        );
        $stmt->execute([":id" => $id]);
        $row = $stmt->fetch();

        return $row === false ? null : $row;
    }

    /**
     * Insert a user and return the new id.
     */
    public function create(
        string $username,
        string $fname,
        string $lname,
        string $password,
        string $email
    ): int {
        $stmt = $this->db->prepare(
            "INSERT INTO users (username, fname, lname, password, email, status)
             VALUES (:username, :fname, :lname, :password, :email, 1)"
        );

        $stmt->execute([
            ":username" => $username,
            ":fname"    => $fname,
            ":lname"    => $lname,
            ":password" => password_hash($password, PASSWORD_DEFAULT),
            ":email"    => $email,
        ]);

        return (int) $this->db->lastInsertId();
    }

    /**
     * Update a user. When $password is empty the current password is kept.
     */
    public function update(
        int $id,
        string $username,
        string $fname,
        string $lname,
        string $email,
        string $password = ""
    ): bool {
        if ($password !== "") {
            $sql = "UPDATE users
                    SET username = :username,
                        fname = :fname,
                        lname = :lname,
                        email = :email,
                        password = :password
                    WHERE id = :id";
            $params = [
                ":username" => $username,
                ":fname"    => $fname,
                ":lname"    => $lname,
                ":email"    => $email,
                ":password" => password_hash($password, PASSWORD_DEFAULT),
                ":id"       => $id,
            ];
        } else {
            $sql = "UPDATE users
                    SET username = :username,
                        fname = :fname,
                        lname = :lname,
                        email = :email
                    WHERE id = :id";
            $params = [
                ":username" => $username,
                ":fname"    => $fname,
                ":lname"    => $lname,
                ":email"    => $email,
                ":id"       => $id,
            ];
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return true;
    }

    /**
     * Delete a user. Returns false when the row was already gone.
     */
    public function delete(int $id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = :id");
        $stmt->execute([":id" => $id]);

        return $stmt->rowCount() > 0;
    }

    /**
     * True when another user already uses this username (case-insensitive,
     * matching the database collation).
     */
    public function usernameExists(string $username, int $excludeId = 0): bool
    {
        return $this->valueExists("username", $username, $excludeId);
    }

    /**
     * True when another user already uses this email address.
     */
    public function emailExists(string $email, int $excludeId = 0): bool
    {
        return $this->valueExists("email", $email, $excludeId);
    }

    private function valueExists(string $column, string $value, int $excludeId = 0): bool
    {
        // $column is only ever set by this class, never by user input.
        $sql = "SELECT 1 FROM users WHERE {$column} = :value";
        $params = [":value" => $value];

        if ($excludeId > 0) {
            $sql .= " AND id <> :id";
            $params[":id"] = $excludeId;
        }

        $sql .= " LIMIT 1";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return $stmt->fetchColumn() !== false;
    }
}
