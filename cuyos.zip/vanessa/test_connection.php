<?php
// Let this diagnostic page handle connection errors itself instead of
// letting config.php terminate the request.
define("DB_SKIP_AUTOCONNECT", true);
require_once __DIR__ . "/dao/config.php";

$connected     = false;
$error         = "";
$serverVersion = "";
$currentDb     = "";

// Full details are shown on localhost, or on the live site when the correct
// key is supplied: test_connection.php?key=vanessa-db-check
$showDetails = $isLocal
    || (isset($_GET["key"]) && is_string($_GET["key"]) && hash_equals(DB_DEBUG_KEY, $_GET["key"]));

try {
    $db            = dbConnect();
    $connected     = true;
    $serverVersion = (string) $db->getAttribute(PDO::ATTR_SERVER_VERSION);
    $currentDb     = (string) $db->query("SELECT DATABASE()")->fetchColumn();
} catch (PDOException $e) {
    $error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Database Connection</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body class="centered-page">

    <div class="container narrow">
        <div class="card">

            <div class="card-header">
                <h1>Database Connection</h1>
            </div>

            <div class="card-body">
                <?php if ($connected): ?>
                    <p class="status status-ok">Connection successful</p>
                    <p class="muted">
                        The application is connected to the MySQL database.
                    </p>
                <?php else: ?>
                    <p class="status status-fail">Connection failed</p>
                    <p class="muted">
                        The application could not connect to the MySQL database.
                        Check the credentials in <code>dao/config.php</code>.
                    </p>
                <?php endif; ?>

                <?php if ($showDetails): ?>
                    <hr>

                    <dl class="kv">
                        <dt>Environment</dt>
                        <dd><?= htmlspecialchars($currentEnv, ENT_QUOTES, "UTF-8") ?></dd>

                        <dt>Host</dt>
                        <dd><?= htmlspecialchars($host, ENT_QUOTES, "UTF-8") ?>:<?= (int) $dbPort ?></dd>

                        <dt>Database</dt>
                        <dd><?= htmlspecialchars($dbname, ENT_QUOTES, "UTF-8") ?></dd>

                        <dt>Username</dt>
                        <dd><?= htmlspecialchars($dbUser, ENT_QUOTES, "UTF-8") ?></dd>

                        <dt>Connection method</dt>
                        <dd>PDO (MySQL)</dd>

                        <?php if ($connected): ?>
                            <dt>Server version</dt>
                            <dd><?= htmlspecialchars($serverVersion, ENT_QUOTES, "UTF-8") ?></dd>

                            <dt>Active database</dt>
                            <dd><?= htmlspecialchars($currentDb, ENT_QUOTES, "UTF-8") ?></dd>
                        <?php endif; ?>
                    </dl>

                    <?php if (!$connected): ?>
                        <div class="alert alert-danger">
                            <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        Detailed diagnostics are hidden on the live site.
                    </div>
                <?php endif; ?>
            </div>

            <div class="card-footer">
                <a href="test_connection.php" class="btn btn-secondary">Retry</a>
                <a href="pages/read.php" class="btn btn-primary">View Users</a>
            </div>

        </div>

        <p class="text-center muted small">Database connection test</p>
    </div>

</body>
</html>
